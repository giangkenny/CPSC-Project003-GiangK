import pygame
from pygame.sprite import Sprite


class Alien(Sprite):
    # A Class to rep a single alien in fleet.
    def __init__(self, ai_settings, screen):
        super(Alien, self).__init__()
        self.screen = screen
        self.ai_settings = ai_settings

        # Load the alien image and set its rect attribute. 'images/alienD/sprite_1.png'
        self.image = pygame.transform.scale((pygame.image.load('images/alien.png')), (60, 60))
        """
        self.death_animation = [pygame.transform.scale((pygame.image.load('images/alienD/sprite_1.png')), (60, 60)),
                                pygame.transform.scale((pygame.image.load('images/alienD/sprite_2.png')), (60, 60)),
                                pygame.transform.scale((pygame.image.load('images/alienD/sprite_3.png')), (60, 60))]
        
        """
        self.rect = self.image.get_rect()
        self.death_animation1 = pygame.transform.scale((pygame.image.load('images/alienD/sprite_1.png')), (60, 60))
        self.death_animation2 = pygame.transform.scale((pygame.image.load('images/alienD/sprite_2.png')), (60, 60))
        self.death_animation3 = pygame.transform.scale((pygame.image.load('images/alienD/sprite_3.png')), (60, 60))

        # Start each new alien near the top left of the screen.
        self.rect.x = self.rect.width
        self.rect.y = self.rect.height

        # Store the alien's exact pos as a decimal
        self.x = float(self.rect.x)

    def update(self):
        # Moving the alien
        self.x += (self.ai_settings.alien_speed_factor * self.ai_settings.fleet_direction)
        self.rect.x = self.x

    def check_edges(self):
        # return true if alien hits the wall
        screen_rect = self.screen.get_rect()
        if self.rect.right >= screen_rect.right:
            return True
        elif self.rect.left <= 0:
            return True

    def blitme(self):
        # Drawing the alien at its current location.
        self.screen.blit(self.image, self.rect)

    def death_animation(self):
        for i in range(100):
            if i <= 33:
                self.screen.blit(self.death_animation1, self.rect)
                pygame.display.flip()
            elif i <= 66:
                self.screen.blit(self.death_animation2, self.rect)
                pygame.display.flip()
            else:
                self.screen.blit(self.death_animation3, self.rect)
                pygame.display.flip()

    """
                if i <= 33:
                image = self.death_animation[0]
                self.screen.blit(image, self.rect)
                pygame.display.flip()
            elif i <= 66:
                self.screen.blit(self.death_animation[1], self.rect)
                pygame.display.flip()
            else:
                self.screen.blit(self.death_animation[2], self.rect)
                pygame.display.flip()
    """
