import pygame

from settings import Settings
from ship import Ship
import game_functions as gf
from pygame.sprite import Group
from game_stats import GameStats
from button import Button
from button import Highscore
from button import Title
from button import PointText
from home_screen import HomeScreen
from scoreboard import Scoreboard


def run_game():
    # STarting game and create a screen object.
    pygame.init()
    ai_settings = Settings()
    screen = pygame.display.set_mode((ai_settings.screen_width, ai_settings.screen_height))
    pygame.display.set_caption("Alien Invasion")
    # Making a group to store the bullets in.
    bullets = Group()
    # Making of an alien in a group
    aliens = Group()

    # Make a ship
    ship = Ship(ai_settings, screen)

    gf.create_fleet(ai_settings, screen, ship, aliens)

    # Create an instance to store game stats.
    stats = GameStats(ai_settings)

    # Making the play Button
    play_button = Button(screen, "Play")
    highscore_button = Highscore(screen, "Highscore")
    title = Title(screen, "SPACE INVADERS")

    # Making home screen
    home_screen = HomeScreen(screen, stats=stats)
    point_text = PointText(screen, "50")
    point_text2 = PointText(screen, "100")
    point_text3 = PointText(screen, "200")

    # Making scoreboard
    sb = Scoreboard(ai_settings, screen, stats)

    # Start the main loop for the game
    while True:
        gf.check_events(ai_settings, screen, stats, sb, play_button, highscore_button, ship, aliens, bullets)
        if stats.game_active:
            ship.update()
            gf.update_bullets(ai_settings, screen, stats, sb, ship, aliens, bullets)
            gf.update_aliens(ai_settings, stats, screen, sb, ship, aliens, bullets)
        gf.update_screen(ai_settings, screen, stats, sb, ship, aliens, bullets, play_button,
                         highscore_button=highscore_button, title=title, home_screen=home_screen,
                         point_text=point_text, point_text2=point_text2, point_text3=point_text3)


run_game()
