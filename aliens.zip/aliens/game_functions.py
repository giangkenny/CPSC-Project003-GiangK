import sys
import pygame
from bullet import Bullet
from time import sleep
from alien import Alien
from alien1 import Alien1
from alien2 import Alien2
from alien3 import Alien3
from home_screen import HomeScreen
from button import PlainText

pygame.init()
hit = pygame.mixer.Sound('hit.wav')
dead = pygame.mixer.Sound('dead.wav')
bg_music = pygame.mixer.Sound('music/bg_music.wav')
bg_music2 = pygame.mixer.Sound('music/bg_music2.wav')
bg_music3 = pygame.mixer.Sound('music/bg_music3.wav')


def check_events(ai_settings, screen, stats, sb, play_button, highscore_button, ship, aliens, bullets):
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()

        elif event.type == pygame.KEYDOWN:
            check_keydown_events(event, ai_settings, screen, ship, bullets)

        elif event.type == pygame.KEYUP:
            check_keyup_events(event, ship)
        elif event.type == pygame.MOUSEBUTTONDOWN:
            mouse_x, mouse_y = pygame.mouse.get_pos()
            check_play_button(ai_settings, screen, stats, sb, play_button, ship, aliens, bullets, mouse_x, mouse_y)
            check_highscore_button(stats, highscore_button, mouse_x, mouse_y)


def check_keydown_events(event, ai_settings, screen, ship, bullets):
    if event.key == pygame.K_RIGHT:
        ship.moving_right = True
    elif event.key == pygame.K_LEFT:
        ship.moving_left = True
    elif event.key == pygame.K_SPACE:
        fire_bullet(ai_settings, screen, ship, bullets)
    # Quiting the game by pressing Q
    elif event.key == pygame.K_q:
        sys.exit()


def check_play_button(ai_settings, screen, stats, sb, play_button, ship, aliens, bullets, mouse_x, mouse_y):
    button_clicked = play_button.rect.collidepoint(mouse_x, mouse_y)
    if button_clicked and not stats.game_active:
        stats.reset_stats()
        ai_settings.initialize_dynamic_settings()
        stats.game_active = True
        stats.hs_menu = False
        print("Was Play Clicked")

        # Reset Score Board Images
        sb.prep_score()
        sb.prep_high_score()
        sb.prep_level()
        sb.prep_ships()

        # Empty the list of aliens and bullets.
        aliens.empty()
        bullets.empty()

        # Create a new fleet and center the ship.
        create_fleet(ai_settings, screen, ship, aliens)
        ship.center_ship()

        # Hide mouse
        pygame.mouse.set_visible(False)


def check_highscore_button(stats, highscore_button, mouse_x, mouse_y):
    button_clicked = highscore_button.rect.collidepoint(mouse_x, mouse_y)

    if button_clicked and not stats.game_active:
        stats.game_active = False
        stats.hs_menu = True
        print("Was clicked, highscore was clicked")


def check_high_score(stats, sb):
    # Check to see if there's a new high score.
    if stats.score > stats.high_score:
        stats.high_score = stats.score
        sb.prep_high_score()


def ship_hit(ai_settings, stats, screen, sb, ship, aliens, bullets):
    if stats.ships_left > 0:
        # decrement ships_left.
        stats.ships_left -= 1

        # Update Lives
        sb.prep_ships()

        # Empty the list of aliens and bullets.
        aliens.empty()
        bullets.empty()

        # create new fleet and center the ship
        create_fleet(ai_settings, screen, ship, aliens)
        ship.center_ship()

        # Sound
        dead.play()

        # Pausing
        sleep(0.5)

    else:
        record_highscore(stats=stats)
        stats.game_active = False
        pygame.mouse.set_visible(True)


def take_first(elem):
    return elem[0]


def record_highscore(stats):
    f = open("highscore/highscore.txt", "a+")
    val = input("Enter your name: ")
    score = str(stats.score) + " " + val + "\n"
    f.write(score)
    f.close()
    f = open("highscore/highscore.txt", "r")
    file = f.readlines()
    f.close()
    number_list = []

    for i in range(len(file)):
        points = file[i]
        points_int = [int(s) for s in points.split() if s.isdigit()]
        points_str = [str(s) for s in points.split() if s.isalpha()]
        point_int = int(points_int[0])
        point_str = str(points_str[0])
        tup_x = (point_int, point_str)
        number_list.append(tup_x)

    number_list.sort(key=take_first, reverse=True)

    first_x = [x[0] for x in number_list]
    second_x = [x[1] for x in number_list]

    f = open("highscore/highscore.txt", "w+")

    for i in range(10):
        string_of_list = str(first_x[i]) + " " + str(second_x[i])
        f.write(string_of_list + "\n")

    f.close()


def create_fleet(ai_settings, screen, ship, aliens):
    """
    Create a full fleet of aliens.
    Create an alien and find the number of aliens in a row.
    Spacing b/t each alien is equal to one alien width.
    """
    bg_music.stop()
    bg_music.play(-1, 0)
    alien = Alien(ai_settings, screen)
    number_aliens_x = get_number_aliens_x(ai_settings, alien.rect.width)
    number_rows = get_number_rows(ai_settings, ship.rect.height, alien.rect.height)

    # Create the first row of aliens.
    for row_number in range(number_rows):
        if row_number % 2 == 0:
            for alien_number in range(number_aliens_x):
                # Create an alien and place it in the row.
                create_alien(ai_settings, screen, aliens, alien_number, row_number)
        else:
            for alien_number in range(number_aliens_x):
                # Create an alien and place it in the row.
                create_alien1(ai_settings, screen, aliens, alien_number, row_number)


def create_alien(ai_settings, screen, aliens, alien_number, row_number):
    alien = Alien1(ai_settings, screen)
    alien_width = alien.rect.width
    alien.x = alien_width + 2 * alien_width * alien_number
    alien.rect.x = alien.x
    alien.rect.y = alien.rect.height + 2 * alien.rect.height * row_number
    aliens.add(alien)


def create_alien1(ai_settings, screen, aliens, alien_number, row_number):
    alien = Alien2(ai_settings, screen)
    alien_width = alien.rect.width
    alien.x = alien_width + 2 * alien_width * alien_number
    alien.rect.x = alien.x
    alien.rect.y = alien.rect.height + 2 * alien.rect.height * row_number
    aliens.add(alien)


def create_ufo(ai_settings, screen):
    alien = Alien3(ai_settings=ai_settings, screen=screen)
    alien.rect.x = alien.x


def check_fleet_edges(ai_settings, aliens):
    # Respond if any of the aliens hits the edge of the screen
    for alien in aliens.sprites():
        if alien.check_edges():
            change_fleet_direction(ai_settings, aliens)
            break


def change_fleet_direction(ai_settings, aliens):
    for alien in aliens.sprites():
        alien.rect.y += ai_settings.fleet_drop_speed
    ai_settings.fleet_direction *= -1


def get_number_aliens_x(ai_settings, alien_width):
    available_space_x = ai_settings.screen_width - 2 * alien_width
    number_aliens_x = int(available_space_x / (2 * alien_width))
    return number_aliens_x


def get_number_rows(ai_settings, ship_height, alien_height):
    """
    Determine the number of rows of aliens that fit on the screen.
    """
    available_space_y = (ai_settings.screen_height - (3 * alien_height) - ship_height)
    number_rows = int(available_space_y / (2 * alien_height))
    return number_rows


def check_keyup_events(event, ship):
    if event.key == pygame.K_RIGHT:
        ship.moving_right = False
    elif event.key == pygame.K_LEFT:
        ship.moving_left = False


def check_aliens_bottom(ai_settings, stats, screen, sb, ship, aliens, bullets):
    # check if aliens hit the bottom of the screen
    screen_rect = screen.get_rect()
    for alien in aliens.sprites():
        if alien.rect.bottom >= screen_rect.bottom:
            # This will also trigger game over
            ship_hit(ai_settings, stats, screen, sb, ship, aliens, bullets)
            break


def fire_bullet(ai_settings, screen, ship, bullets):
    # Create a new bullet and add it to the bullet group.
    if len(bullets) < ai_settings.bullets_allowed:
        new_bullet = Bullet(ai_settings, screen, ship)
        bullets.add(new_bullet)


def check_bullet_alien_collisions(ai_settings, screen, stats, sb, ship, aliens, bullets):
    # Responds to bullet-alien collisions and remove
    collisions = pygame.sprite.groupcollide(bullets, aliens, True, True)

    if collisions:
        for aliens in collisions.values():
            alien = Alien(ai_settings=ai_settings, screen=screen)
            stats.score += ai_settings.alien1_points * len(aliens)
            ai_settings.number_of_aliens -= 1
            sb.prep_score()
            alien.death_animation()
        hit.play()
        check_high_score(stats, sb)
        print("Number of Aliens: ", ai_settings.number_of_aliens)

    if ai_settings.number_of_aliens < 2:
        bg_music2.stop()
        bg_music.stop()
        bg_music3.play(-1, 0)
    elif ai_settings.number_of_aliens < 18:
        bg_music3.stop()
        bg_music.stop()
        bg_music2.play(-1, 0)

    if len(aliens) == 0:
        # Destroy existing bullets and create new fleet
        bg_music2.stop()
        bg_music3.stop()
        bg_music.stop()
        bullets.empty()
        ai_settings.increase_speed()
        # Increasing level
        stats.level += 1
        sb.prep_level()

        create_fleet(ai_settings, screen, ship, aliens)


def update_bullets(ai_settings, screen, stats, sb, ship, aliens, bullets):
    """"
    Update pos of bullets and get rid of old bullets.
    """
    bullets.update()

    # Get rid of bullets that have disappeared.
    for bullet in bullets.copy():
        if bullet.rect.bottom <= 0:
            bullets.remove(bullet)

    """
    check for nay bullets that have hit aliens
    if so, get rid of the bullet + alien
    """
    check_bullet_alien_collisions(ai_settings, screen, stats, sb, ship, aliens, bullets)


def update_screen(ai_settings, screen, stats, sb, ship, aliens, bullets, play_button, highscore_button, title,
                  home_screen, point_text, point_text2, point_text3):
    # Redraw the screen during each pass through of the loop.
    screen.fill(ai_settings.bg_color)
    # Redraw all bullets behind ship and aliens
    for bullet in bullets.sprites():
        bullet.draw_bullet()
    ship.blitme()
    aliens.draw(screen)
    # Draw score
    sb.show_score()

    # Draw the play button if the game is inactive.
    if stats.hs_menu:
        menu = HomeScreen(screen=screen, stats=stats)
        menu.highscore_screen(screen=screen)
        highscore_title = PlainText(screen=screen, msg="High Scores: ")
        highscore_title.prep_location(400, 50)
        highscore_title.draw_plain_text()
        highscore_button.prep_location(0, 0)
        play_button.prep_location(600, 700)
        play_button.draw_button()

    elif not stats.game_active and not stats.hs_menu:
        home_screen.screen_fill()
        point_text.prep_location(500, 210)
        point_text.draw_point()
        point_text2.prep_location(500, 310)
        point_text2.draw_point()
        point_text3.prep_location(500, 410)
        point_text3.draw_point()
        play_button.prep_msg()
        play_button.draw_button()
        highscore_button.prep_location(600, 700)
        highscore_button.draw_highscore()
        title.draw_title()
    # Make the most recently drawn screen visible
    pygame.display.flip()


def update_aliens(ai_settings, stats, screen, sb, ship, aliens, bullets):
    check_fleet_edges(ai_settings, aliens)
    aliens.update()

    # Look for alien ship collisions.
    if pygame.sprite.spritecollideany(ship, aliens):
        ship_hit(ai_settings, stats, screen, sb, ship, aliens, bullets)

    check_aliens_bottom(ai_settings, stats, screen, sb, ship, aliens, bullets)
